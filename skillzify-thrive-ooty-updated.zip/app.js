document.addEventListener('DOMContentLoaded', () => {
    // 1. Sticky Navbar on Scroll
    const header = document.getElementById('header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // 2. Mobile Navigation Menu Toggle
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');
    
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close menu when clicking links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // 3. Theme Toggle (Dark/Light mode)
    const themeToggleBtn = document.getElementById('theme-toggle');
    const currentTheme = localStorage.getItem('theme') || 'dark';

    // Apply initial theme
    document.documentElement.setAttribute('data-theme', currentTheme);

    themeToggleBtn.addEventListener('click', () => {
        let theme = document.documentElement.getAttribute('data-theme');
        let newTheme = theme === 'light' ? 'dark' : 'light';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    });

    // 4. FAQ Accordion
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const header = item.querySelector('.faq-header');
        const body = item.querySelector('.faq-body');
        
        header.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all items
            faqItems.forEach(otherItem => {
                otherItem.classList.remove('active');
                otherItem.querySelector('.faq-body').style.maxHeight = null;
            });

            if (!isActive) {
                item.classList.add('active');
                body.style.maxHeight = body.scrollHeight + 'px';
            }
        });
    });

    // 5. Testimonial Carousel
    const track = document.getElementById('carousel-track');
    const slides = Array.from(track.children);
    const prevBtn = document.getElementById('carousel-prev');
    const nextBtn = document.getElementById('carousel-next');
    const dotsContainer = document.getElementById('carousel-dots');
    
    let currentIndex = 0;
    let autoSlideInterval;

    // Create Navigation Dots
    slides.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.classList.add('carousel-dot');
        if (index === 0) dot.classList.add('active');
        dot.addEventListener('click', () => moveToSlide(index));
        dotsContainer.appendChild(dot);
    });

    const dots = Array.from(dotsContainer.children);

    const updateDots = (index) => {
        dots.forEach(dot => dot.classList.remove('active'));
        dots[index].classList.add('active');
    };

    const moveToSlide = (index) => {
        if (index < 0) index = slides.length - 1;
        if (index >= slides.length) index = 0;
        
        track.style.transform = `translateX(-${index * 100}%)`;
        currentIndex = index;
        updateDots(index);
    };

    prevBtn.addEventListener('click', () => {
        moveToSlide(currentIndex - 1);
        resetAutoSlide();
    });

    nextBtn.addEventListener('click', () => {
        moveToSlide(currentIndex + 1);
        resetAutoSlide();
    });

    const startAutoSlide = () => {
        autoSlideInterval = setInterval(() => {
            moveToSlide(currentIndex + 1);
        }, 5000); // Change testimonial every 5 seconds
    };

    const resetAutoSlide = () => {
        clearInterval(autoSlideInterval);
        startAutoSlide();
    };

    startAutoSlide();

    // 6. Interactive Package/Fee Calculator
    const programSelect = document.getElementById('calc-program');
    const durationSelect = document.getElementById('calc-duration');
    const typeOptions = document.querySelectorAll('.segmented-option');
    const roomSelect = document.getElementById('calc-room');
    const roomGroup = document.getElementById('calc-room-group');
    const calculatedPriceEl = document.getElementById('calculated-price');
    const calculatedPeriodEl = document.getElementById('calculated-period');
    
    // Breakdown elements
    const breakdownContainer = document.getElementById('calc-breakdown');
    const breakdownTuition = document.getElementById('breakdown-tuition');
    const breakdownStay = document.getElementById('breakdown-stay');
    
    let selectedType = 'commuter'; // Default stay option

    // Pricing Database (INR)
    const baseRates = {
        'it': 10000,
        'dev': 14000,
        'iot': 15000,
        'cloud': 16000,
        'cyber': 18000,
        'analytics': 14000,
        'ui-ux': 12000
    };

    const durationMultipliers = {
        '1': 1,
        '3': 2.6, // Discounted for 3 months
        '6': 4.8  // Discounted for 6 months
    };

    const calculateFee = () => {
        const program = programSelect.value;
        const durationMonths = parseInt(durationSelect.value);
        
        const baseRate = baseRates[program] || 10000;
        const multiplier = durationMultipliers[durationSelect.value] || 1;
        
        let tuitionFee = baseRate * multiplier;
        let stayFee = 0;

        if (selectedType === 'residential') {
            roomGroup.style.display = 'block';
            breakdownContainer.style.display = 'flex';
            
            const roomType = roomSelect.value;
            const accommodationRate = roomType === 'private' ? 25000 : 15000;
            stayFee = accommodationRate * durationMonths;
            
            breakdownTuition.textContent = '₹' + tuitionFee.toLocaleString('en-IN');
            breakdownStay.textContent = '₹' + stayFee.toLocaleString('en-IN');
        } else {
            roomGroup.style.display = 'none';
            breakdownContainer.style.display = 'none';
        }

        const totalFee = tuitionFee + stayFee;
        
        // Formatted to Indian numbering system
        calculatedPriceEl.textContent = '₹' + totalFee.toLocaleString('en-IN');
        
        const stayLabel = selectedType === 'residential' 
            ? `Residential Retreat (${roomSelect.options[roomSelect.selectedIndex].text.split(' - ')[0]})` 
            : 'Commuter';
            
        if (durationMonths === 1) {
            calculatedPeriodEl.textContent = `for 1 Month Course (${stayLabel})`;
        } else {
            calculatedPeriodEl.textContent = `for ${durationMonths} Months Course (${stayLabel})`;
        }
    };

    // Toggle logic for Commuter vs Residential Stay
    typeOptions.forEach(option => {
        option.addEventListener('click', () => {
            typeOptions.forEach(opt => opt.classList.remove('active'));
            option.classList.add('active');
            selectedType = option.dataset.value;
            calculateFee();
        });
    });

    programSelect.addEventListener('change', calculateFee);
    durationSelect.addEventListener('change', calculateFee);
    roomSelect.addEventListener('change', calculateFee);
    
    // Initial run
    calculateFee();

    // Autofill contact form when clicking "Reserve Seat" from the Tuition Configurator
    const reserveSeatBtn = document.getElementById('btn-calc-apply');
    if (reserveSeatBtn) {
        reserveSeatBtn.addEventListener('click', () => {
            const program = programSelect.value;
            const durationText = durationSelect.options[durationSelect.selectedIndex].text;
            const stayText = selectedType === 'residential' 
                ? `Residential Retreat (${roomSelect.options[roomSelect.selectedIndex].text.split(' - ')[0]})` 
                : 'Commuter / Local';
            const price = calculatedPriceEl.textContent;
            
            // 1. Autofill dropdown
            const formProgramSelect = document.getElementById('form-program');
            if (formProgramSelect) {
                formProgramSelect.value = program;
                formProgramSelect.dispatchEvent(new Event('change'));
                formProgramSelect.dispatchEvent(new Event('blur'));
            }
            
            // 2. Autofill message
            const formMessageTextarea = document.getElementById('form-message');
            if (formMessageTextarea) {
                formMessageTextarea.value = `I'd like to reserve my seat for the ${programSelect.options[programSelect.selectedIndex].text}.\n- Selected Duration: ${durationText}\n- Stay Option: ${stayText}\n- Estimated Package: ${price}`;
                formMessageTextarea.dispatchEvent(new Event('blur'));
            }
        });
    }

    // Autofill contact form when clicking "Apply via WhatsApp" from the Internship banner
    const internshipApplyBtn = document.getElementById('btn-internship-apply');
    if (internshipApplyBtn) {
        internshipApplyBtn.addEventListener('click', () => {
            // 1. Autofill dropdown
            const formProgramSelect = document.getElementById('form-program');
            if (formProgramSelect) {
                formProgramSelect.value = 'ui-ux';
                formProgramSelect.dispatchEvent(new Event('change'));
                formProgramSelect.dispatchEvent(new Event('blur'));
            }
            
            // 2. Autofill message
            const formMessageTextarea = document.getElementById('form-message');
            if (formMessageTextarea) {
                formMessageTextarea.value = `I am interested in applying for the 15-Day Paid Online UI/UX Internship program (Fee: ₹5,000). Please share more details!`;
                formMessageTextarea.dispatchEvent(new Event('blur'));
            }
        });
    }

    // 7. Form floating label validation and submit success logic
    const contactForm = document.getElementById('enrollment-form');
    const successContainer = document.getElementById('form-success');
    const submitBtn = contactForm.querySelector('button[type="submit"]');

    // Simple float label validation: verify values
    const formControls = contactForm.querySelectorAll('.form-control');
    formControls.forEach(control => {
        control.addEventListener('blur', () => {
            if (control.value.trim() !== '') {
                control.setAttribute('placeholder-shown', 'false');
            } else {
                control.removeAttribute('placeholder-shown');
            }
        });
    });

    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Get Form Values
        const name = document.getElementById('form-name').value;
        const email = document.getElementById('form-email').value;
        const phone = document.getElementById('form-phone').value;
        const programSelect = document.getElementById('form-program');
        const programName = programSelect.options[programSelect.selectedIndex].text;
        const message = document.getElementById('form-message').value;

        // Perform mock submission visual state changes
        submitBtn.innerHTML = 'Redirecting to WhatsApp... <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path></svg>';
        submitBtn.disabled = true;

        // Construct professional WhatsApp message
        const whatsappText = `*New Course Enquiry - Skillzify Thrive Ooty*\n\n` +
            `*Name:* ${name}\n` +
            `*Email:* ${email}\n` +
            `*Phone:* ${phone}\n` +
            `*Course interest:* ${programName}\n` +
            `*Message/Goals:* ${message}\n\n` +
            `Sent from Skillzify Thrive website`;

        const whatsappUrl = `https://wa.me/916381124089?text=${encodeURIComponent(whatsappText)}`;

        setTimeout(() => {
            // Open WhatsApp Link in a new tab
            window.open(whatsappUrl, '_blank');

            // Elegant transitions
            contactForm.style.display = 'none';
            
            // Populating success screen detail
            document.getElementById('success-message-detail').innerHTML = `Hey <strong>${name}</strong>, we have redirected you to WhatsApp to send your enquiry directly to our admissions office. A copy of your submission details for <strong>${programName}</strong> has been logged. Our mentors will also connect with you on <strong>${phone}</strong> within 24 hours!`;
            
            successContainer.style.display = 'block';
            successContainer.style.opacity = 0;
            // Trigger animation
            setTimeout(() => {
                successContainer.style.transition = 'opacity 0.6s ease';
                successContainer.style.opacity = 1;
            }, 50);
        }, 1200);
    });
    // 8. Navigation link tracking & auto active-link highlight on scroll
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('.nav-link');

    window.addEventListener('scroll', () => {
        let currentSectionId = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 150;
            const sectionHeight = section.clientHeight;
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                currentSectionId = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${currentSectionId}`) {
                link.classList.add('active');
            }
        });
    });

    // 9. Interactive Syllabus Modals
    const syllabusDatabase = {
        'it': {
            title: 'IT Training',
            desc: 'Build strong foundations and advance your tech skills. Learn hardware essentials, PC setup, troubleshooting, and professional routing.',
            icon: `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>`,
            syllabus: [
                { week: 'Week 1', title: 'PC Architecture & Assembly', desc: 'Understanding CPU, motherboard, RAM, storage, power supply units and assembly.' },
                { week: 'Week 2', title: 'BIOS/UEFI & OS Installation', desc: 'Configuring BIOS settings, disk partitioning, installing Windows/Linux operating systems.' },
                { week: 'Week 3', title: 'Networking & Routing Protocols', desc: 'IP subnetting, configuring switches, home routers, and basic packet troubleshooting.' },
                { week: 'Week 4', title: 'Hardware Support & Diagnostic Labs', desc: 'Vulnerability scans, OS recovery, registry fixes, and support desk ticketing.' }
            ],
            projects: [
                'Custom Desktop PC Assembly and hardware load testing',
                'Soho Home-Office Router & Switch network topology design'
            ],
            tools: ['Cisco Packet Tracer', 'Rufus Bootmaker', 'Wireshark Diagnostics', 'HWMonitor']
        },
        'dev': {
            title: 'Software Development',
            desc: 'Turn ideas into powerful, real-world applications. Master databases, object-oriented coding, and web app architectures.',
            icon: `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>`,
            syllabus: [
                { week: 'Week 1-2', title: 'Modern JavaScript (ES6+) & Frontend Foundations', desc: 'HTML5 semantic tags, CSS3 Grid/Flexbox layouts, JS DOM API, events, and fetch requests.' },
                { week: 'Week 3-4', title: 'Node.js & Express REST APIs', desc: 'Building backends, handling routing, middleware, and database connectivity.' },
                { week: 'Week 5-6', title: 'React.js Client-Side Routing & State', desc: 'Components, state, hooks (useState, useEffect), global context, and build bundling.' }
            ],
            projects: [
                'Dynamic E-commerce store with integrated shopping cart API',
                'Real-time collaborative Chat Application using WebSockets'
            ],
            tools: ['VS Code', 'Git / GitHub', 'Postman API Client', 'MongoDB Compass', 'Vite Dev Tools']
        },
        'iot': {
            title: 'IoT Projects',
            desc: 'Innovate and connect with smart solutions. Interface physical sensors, microcontrollers, and cloud telemetry services.',
            icon: `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="15" x2="23" y2="15"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="15" x2="4" y2="15"></line></svg>`,
            syllabus: [
                { week: 'Week 1', title: 'Microcontroller Circuit Design', desc: 'Breadboarding basics, GPIO pins, Ohm\'s law, resistors, LEDs, and power rails.' },
                { week: 'Week 2', title: 'Firmware Programming (C++ & MicroPython)', desc: 'Reading analogue & digital sensors (DHT11, PIR motion, ultrasonic sensors).' },
                { week: 'Week 3', title: 'Network Connectivity & MQTT Protocols', desc: 'ESP32 Wi-Fi setup, connecting clients, publisher-subscriber communication models.' },
                { week: 'Week 4', title: 'Cloud Telemetry & Smart Control', desc: 'Interface with Adafruit IO, AWS IoT Core, triggering relays for appliance control.' }
            ],
            projects: [
                'Smart Weather Telemetry Station with cloud charting dashboard',
                'Voice/Web controlled Smart Home Switchboard system'
            ],
            tools: ['Arduino IDE', 'Thonny Python Editor', 'Fritzing Schematics', 'MQTT Box Client']
        },
        'cloud': {
            title: 'Cloud Computing',
            desc: 'Learn, deploy, and manage scalable cloud solutions. Set up serverless API backend services, virtualization, and deployments.',
            icon: `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path></svg>`,
            syllabus: [
                { week: 'Week 1', title: 'Cloud Essentials & IAM Security', desc: 'Virtualization models, AWS account structures, policy-based access control, billing alarms.' },
                { week: 'Week 2', title: 'Compute (EC2) & Storage Design (S3/EBS)', desc: 'Hosting websites on webserver virtual instances, scaling volumes, backup policies.' },
                { week: 'Week 3', title: 'Virtual Private Networks (VPC)', desc: 'Subnets, internet gateways, NAT routers, custom route tables, and NACLs.' },
                { week: 'Week 4', title: 'Serverless Compute & Infrastructure as Code', desc: 'AWS Lambda functions, API Gateway setups, and declarative infrastructure coding.' }
            ],
            projects: [
                'Auto-scaling load-balanced virtual server stack in multiple zones',
                'Declarative resource deployment code template via Terraform'
            ],
            tools: ['AWS Management Console', 'AWS Command Line Interface', 'Terraform Engine', 'Docker Containers']
        },
        'cyber': {
            title: 'Cyber Security',
            desc: 'Protect digital assets and build a secure tomorrow. Learn network defense protocols, ethical hacking, and vulnerability testing.',
            icon: `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>`,
            syllabus: [
                { week: 'Week 1', title: 'Networking Defense Protocols & Cryptography', desc: 'TCP/IP headers, handshake reviews, symmetric vs asymmetric encryption, SSH setup.' },
                { week: 'Week 2', title: 'Footprinting, Scanning & Reconnaissance', desc: 'Passive OSINT searches, active Nmap ports mapping, banner grabbing.' },
                { week: 'Week 3', title: 'Web App Pentesting (OWASP Top 10)', desc: 'Intercepting requests, SQL Injection payloads, Cross-Site Scripting exploits.' },
                { week: 'Week 4', title: 'Intrusion Detection & Network Audits', desc: 'Analyzing PCAP files, writing Snort firewall rules, defensive security reports.' }
            ],
            projects: [
                'Complete vulnerability assessment report on target test server',
                'Active Intrusion Detection monitoring dashboard setup using Snort'
            ],
            tools: ['Kali Linux', 'Nmap Port Scanner', 'Wireshark Sniffer', 'Burp Suite Proxy', 'Metasploit Framework']
        },
        'analytics': {
            title: 'Data Analytics',
            desc: 'Transform data into insights and drive decisions. Master analytical workflows, data scrubbing, modeling, and visualization.',
            icon: `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>`,
            syllabus: [
                { week: 'Week 1-2', title: 'Python Libraries for Data Manipulation', desc: 'Jupyter notebook setup, Numpy arrays, Pandas series & Dataframes, cleaning null values.' },
                { week: 'Week 3-4', title: 'Structured Query Language (SQL)', desc: 'Writing subqueries, complex database joins, CTEs, and window functions.' },
                { week: 'Week 5-6', title: 'Data Visualisation & Business Intelligence', desc: 'Making charts in Seaborn, building interactive sales dashboard charts in Tableau/Power BI.' }
            ],
            projects: [
                'Interactive Sales Performance Dashboard with geo-mapping overlays',
                'Python Exploratory Data Analysis report on global climate datasets'
            ],
            tools: ['Jupyter Notebook', 'Tableau Desktop', 'Power BI Desktop', 'SQLite Database Engine']
        },
        'ui-ux': {
            title: 'UI/UX Graphics Design',
            desc: 'Design beautiful experiences that inspire and engage. Learn user research, wireframing, layout principles, and interactive prototypes.',
            icon: `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path><path d="M12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18Z"></path></svg>`,
            syllabus: [
                { week: 'Week 1', title: 'UX Research & Ideation Workshops', desc: 'Formulating problem statements, conducting interviews, creating user personas and journeys.' },
                { week: 'Week 2', title: 'Information Architecture & Wireframes', desc: 'Designing site structures, mapping task flows, drafting low-fidelity paper wireframes.' },
                { week: 'Week 3-4', title: 'Figma Prototyping & Design Systems', desc: 'Using Auto-layout, variants, components, interactive states, and design tokens.' },
                { week: 'Week 5-6', title: 'Graphics Design & Visual Branding', desc: 'Vector illustrations in Adobe Illustrator, logo designing and color scheme guidelines.' }
            ],
            projects: [
                'High-fidelity interactive prototype of a Hyper-local Delivery mobile app',
                'Complete branding design catalog with vector assets for target company'
            ],
            tools: ['Figma Editor', 'Adobe Illustrator', 'Adobe Photoshop', 'Miro Whiteboarding']
        }
    };

    const modal = document.getElementById('syllabus-modal');
    const modalClose = document.getElementById('modal-close');
    const modalTitle = document.getElementById('modal-title');
    const modalSubtitle = document.getElementById('modal-subtitle');
    const modalIcon = document.getElementById('modal-icon');
    const modalTabBtns = document.querySelectorAll('.modal-tab-btn');
    const modalTabContents = document.querySelectorAll('.modal-tab-content');
    const modalEnrollBtn = document.getElementById('btn-modal-enroll');
    
    let activeProgramKey = '';

    // Handle course links click to trigger modal
    document.querySelectorAll('.program-card').forEach(card => {
        const link = card.querySelector('.program-link');
        const programKey = card.id.replace('program-', '');
        
        if (link) {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                openSyllabusModal(programKey);
            });
        }
    });

    const openSyllabusModal = (key) => {
        const data = syllabusDatabase[key];
        if (!data) return;

        activeProgramKey = key;
        modalTitle.textContent = data.title;
        modalSubtitle.textContent = data.desc;
        modalIcon.innerHTML = data.icon;

        // Build Syllabus content
        let syllabusHtml = '<div class="weekly-list">';
        data.syllabus.forEach(item => {
            syllabusHtml += `
                <div class="weekly-item">
                    <span class="weekly-num">${item.week}</span>
                    <div class="weekly-detail">
                        <h4>${item.title}</h4>
                        <p>${item.desc}</p>
                    </div>
                </div>
            `;
        });
        syllabusHtml += '</div>';
        document.getElementById('tab-syllabus').innerHTML = syllabusHtml;

        // Build Projects content
        let projectsHtml = '<ul class="projects-list">';
        data.projects.forEach(project => {
            projectsHtml += `
                <li class="project-item">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    <span>${project}</span>
                </li>
            `;
        });
        projectsHtml += '</ul>';
        document.getElementById('tab-projects').innerHTML = projectsHtml;

        // Build Tools content
        let toolsHtml = '<div class="tools-grid">';
        data.tools.forEach(tool => {
            toolsHtml += `<span class="tool-badge">${tool}</span>`;
        });
        toolsHtml += '</div>';
        document.getElementById('tab-tools').innerHTML = toolsHtml;

        // Reset to first tab
        switchTab('syllabus');
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    };

    const switchTab = (tabId) => {
        modalTabBtns.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });
        modalTabContents.forEach(content => {
            content.classList.toggle('active', content.id === `tab-${tabId}`);
        });
    };

    modalTabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            switchTab(btn.dataset.tab);
        });
    });

    const closeSyllabusModal = () => {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    };

    modalClose.addEventListener('click', closeSyllabusModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeSyllabusModal();
    });

    // Modal enroll/autofill click handler
    modalEnrollBtn.addEventListener('click', () => {
        closeSyllabusModal();
        
        // 1. Autofill dropdown
        const formProgramSelect = document.getElementById('form-program');
        if (formProgramSelect) {
            formProgramSelect.value = activeProgramKey;
            formProgramSelect.dispatchEvent(new Event('change'));
            formProgramSelect.dispatchEvent(new Event('blur'));
        }
        
        // 2. Autofill message
        const formMessageTextarea = document.getElementById('form-message');
        if (formMessageTextarea) {
            const courseName = syllabusDatabase[activeProgramKey].title;
            formMessageTextarea.value = `I am interested in enrolling in the ${courseName} course. Please contact me with admissions details!`;
            formMessageTextarea.dispatchEvent(new Event('blur'));
        }
        
        // 3. Scroll to contact
        const contactSection = document.getElementById('contact');
        if (contactSection) {
            contactSection.scrollIntoView({ behavior: 'smooth' });
        }
    });

    // 10. Campus Gallery Lightbox
    const lightbox = document.getElementById('lightbox-modal');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxCaption = document.getElementById('lightbox-caption');
    const lightboxClose = document.getElementById('lightbox-close');

    document.querySelectorAll('.ooty-img-box').forEach(box => {
        box.addEventListener('click', () => {
            const img = box.querySelector('img');
            const badge = box.querySelector('.ooty-badge');
            if (img) {
                lightboxImg.src = img.src;
                lightboxCaption.textContent = badge ? badge.textContent : 'Skillzify Thrive Campus';
                lightbox.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        });
    });

    const closeLightbox = () => {
        lightbox.classList.remove('active');
        if (!modal.classList.contains('active')) {
            document.body.style.overflow = '';
        }
    };

    lightboxClose.addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) closeLightbox();
    });

    // 11. Scroll-Triggered Animations (Intersection Observer)
    const initScrollAnimations = () => {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.12
        };

        const revealCallback = (entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animated');
                    observer.unobserve(entry.target);
                }
            });
        };

        const observer = new IntersectionObserver(revealCallback, observerOptions);

        document.querySelectorAll('.reveal-on-scroll, .reveal-card-grid').forEach(el => {
            observer.observe(el);
        });
    };

    // Initialize observer if browser supports it
    if ('IntersectionObserver' in window) {
        initScrollAnimations();
    } else {
        document.querySelectorAll('.reveal-on-scroll, .reveal-card-grid').forEach(el => {
            el.classList.add('animated');
        });
    }
});
